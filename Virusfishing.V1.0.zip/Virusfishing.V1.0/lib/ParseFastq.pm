#########################################################
#
#  majinmin
#  xiejiazheng
#
#  META VIRUS of BGI
#
#  xiejiazheng@genomics.cn
#   2012-3-5
#
#########################################################
#################
# ParseFastq.pm #
#################


package ParseFastq;
{

=head1 NAME

ParseFastq - class for reading a fastq formatted file

=head1 SYNOPSIS

use ParseFastq;
my $fr = new ParseFastq(\*STDIN);
if (!defined $fr){
        die ("Bad reader\n");
}

while (my ($head, $data, $qualsep, $qual) = $fr->getRecord()){
       ...
}

=cut

use strict;

sub new
{
    my $pkg = shift;
    my $file = shift;
    my $headsep = shift;
    my $qualsep = shift;
    my $linesep = shift;

    my $self = {};
    bless $self;

    $self->{headsep} = '@';
    $self->{headsep} = $headsep if defined $headsep;
    $self->{linesep} = '';
    $self->{linesep} = $linesep if defined $linesep;
    $self->{file} = $file;

    $self->{buf} = <$file>;
    if (! defined $self->{buf}){
        print STDERR "File appears empty\n";
        return undef;
#   die("File appears empty\n");
    }
    if ($self->{buf} !~ /^$self->{headsep}/){
        print STDERR "File doesn't start with a header: $headsep\n";
        return undef;
#   die ("File doesn't start with a header: $headsep\n");
    }
    chomp $self->{buf};
#    print STDERR "GOT a line $buf\n";
    return $self;
}

sub getRecord()
{
    my $self = shift;
    my $head;
    my $data;
    my $qualsep;
    my $quality;
    my $len_qual=0;
    my $len_data;

    my $file = $self->{file};

    if (! defined $self->{buf} || $self->{buf} !~ /^$self->{headsep}/){ # record must start with a separator
        return ();
    }
    $head = $self->{buf};
    $head =~ s/^$self->{headsep}//;
    $self->{buf} = <$file>;
    chomp $self->{buf};
    while (defined $self->{buf} && $self->{buf} !~ /^\+/){
        $data .= $self->{buf} . $self->{linesep};
        $self->{buf} = <$file>;
        if (defined $self->{buf}){chomp $self->{buf}};
    }

    $len_data = length($data);
    $qualsep = $self->{buf};

    $self->{buf} = <$file>;
    chomp $self->{buf};
    while ($len_qual < $len_data) {
        $len_qual += length($self->{buf});
        $quality .= $self->{buf} . $self->{linesep};
        $self->{buf} = <$file>;
        if (defined $self->{buf}){chomp $self->{buf}};
    }

    return ($head, $data, $qualsep, $quality);
}
1;
}
