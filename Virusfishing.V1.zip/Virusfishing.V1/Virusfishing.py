#!/usr/bin/python
import argparse
import sys
import os
import re


#################################################################################
#####------------------------- parameters --------------------------------#####

description = """
Virusfishing is a virus screening pipeline for 1000 Insect Transcriptome Evolution 
(1KITE) project to search viruses, construct viral genomes and screen for the 
expressed virus genes and discover viral splicing patterns. Virusfishing also can 
be used in other next generation sequencing data. 

Virusfishing.py is the wrapper script to run other Perl scripts to do the real work 
you choose.

Contact us: zhouchengran@genomics.cn; mengguanliang@genomics.cn

Note: when use 'search' function, NT database and virus database must have been 
indexed with "formatdb" command of blast.

"""

parser = argparse.ArgumentParser(prog="Virusfishing.py", description=description,
						formatter_class=argparse.RawDescriptionHelpFormatter)

subparsers = parser.add_subparsers(dest="command")

parser_search = subparsers.add_parser("search", 
									help="search virus sequences from assembly")
parser_search.add_argument("-i", metavar="<STR>", required=True, 
							help="assembly file")
parser_search.add_argument("-vdb", metavar="<STR>", required=True, 
							help="virus database")
parser_search.add_argument("-gitax", metavar="<STR>", required=True, 
							help="gi_taxid_nucl.dmp.gz")
parser_search.add_argument("-taxname", metavar="<STR>", required=True, 
							help="names.dmp(.gz)")
parser_search.add_argument("-taxnode", metavar="<STR>", required=True, 
							help="nodes.dmp(.gz)")
parser_search.add_argument("-NT", metavar="<STR>", required=True, 
							help="NT database")
parser_search.add_argument("-prefix", metavar="<STR>", required=True, 
							help="outfile prefix")
parser_search.add_argument("-outdir", default="",metavar="<STR>", help="out directory")
parser_search.add_argument("-blastall", metavar="<STR>", help="directory of blastall")

parser_assemble = subparsers.add_parser("assemble", 
									help="do virus assembly based on reference")
parser_assemble.add_argument("-q1", metavar="<STR>", required=True, 
							help="fastq1 file")
parser_assemble.add_argument("-q2", metavar="<STR>", help="fastq2 file")
parser_assemble.add_argument("-ref", metavar="<STR>", required=True, 
							help="reference file, prefix.gi.fa from step 1")
parser_assemble.add_argument("-prefix", metavar="<STR>", required=True, 
							help="outfile prefix")
parser_assemble.add_argument("-outdir",default="", metavar="<STR>", help="out directory")
parser_assemble.add_argument("-bwa", metavar="<STR>", help="directory of BWA")
parser_assemble.add_argument("-samtools", metavar="<STR>", help="directory of samtools")

parser_splicing = subparsers.add_parser("splicing", 
								help="identify splicing pattern of assembly")
parser_splicing.add_argument("-vi", metavar="<STR>", required=True, 
							help="virus assembly")
parser_splicing.add_argument("-q1", metavar="<STR>", required=True, 
							help="fastq1 file")
parser_splicing.add_argument("-q2", metavar="<STR>", help="fastq2 file")
parser_splicing.add_argument("-prefix", metavar="<STR>", required=True, 
							help="outfile prefix")
parser_splicing.add_argument("-outdir", default="", metavar="<STR>", help="out directory")
parser_splicing.add_argument("-tophat", metavar="<STR>", help="directory of tophat")
parser_splicing.add_argument("-bowtie", metavar="<STR>", help="directory of bowtie")


args = parser.parse_args()

workdir = os.getcwd()


bindir = os.path.join(sys.path[0], 'bin')
softdir = os.path.join(sys.path[0], 'software')


def search():
	# NT blast index
	# virus blast index
	
	if (args.outdir==''):
		args.outdir = "%s" % workdir
	tmpfile = args.prefix + ".search.sh"
	fh_tmp = open(tmpfile, 'w')
	
	blast=""
	if args.blastall:
		blast = ":%s" %args.blastall

	tmpout = ""
	tmpout = "export PATH=$PATH:" + softdir + blast +"\n"
	soft = os.path.join(bindir, "Virus_Search.pl")
	tmpout += "perl %s " % soft + "-i %s" % args.i + " -v %s " % args.vdb + \
			 " -nt %s " % args.NT + " -outpre %s " % args.prefix + \
			 " -iden 90 -len 200 -a 2 " + \
			 " -outdir %s " % args.outdir + "\n"
	nt_blastn = args.prefix + ".nt.blastn"
	nt_blastn_besthit = args.prefix + ".nt.blastn.besthit"

	soft = os.path.join(bindir, "Virus_false_removal.pl")
	tmpout += "perl %s " % soft + " -in %s " % nt_blastn_besthit + \
			" -outpre  %s " % args.prefix + " -outdir %s " % args.outdir + \
			" -gitax  %s " % args.gitax + \
			" -taxname  %s " %args.taxname + \
			" -taxnode  %s " % args.taxnode + "\n"
	besthit_virus = args.prefix + ".virus"

	soft = os.path.join(bindir, "Virus_Coverage.pl")
	tmpout += "perl %s " % soft + " -viruslis %s " % besthit_virus + \
			" -blastlis %s " % nt_blastn + \
			" --assemblyfa %s " % args.i + \
			" -gifa %s " % args.NT + \
			" -outpre %s " % args.prefix +\
			" -outdir %s " % args.outdir + "\n"
	
	print(tmpout, file=fh_tmp)
	fh_tmp.close()

def assemble():
	## bwa index
	tmpfile = args.prefix + ".assemble.sh"
	fh_tmp = open(tmpfile, 'w')
	bw = ""
	sam = ""
	tmpout = ""
	
	if (args.outdir==''):
		args.outdir = "%s" % workdir
	if args.bwa:
		bw = ":%s" % args.bwa
	if args.samtools:
		sam = ":%s" % args.samtools
	tmpout = "export PATH=$PATH:" + softdir + bw + sam + "\n"
	
	# reference must be current directory!

	soft = os.path.join(bindir, "Ref_Based_Genome_Assemble.pl")
	q2 = ""
	if args.q2:
		q2 = " -fq2 %s " % args.q2
	tmpout += "perl %s " % soft + " -fq1 %s " % args.q1 + q2 + \
			" -ref %s "  % args.ref + \
			" -outpre %s " % args.prefix + \
			" -outdir %s " % args.outdir + "\n"
	fil_rmd_bam = args.prefix + ".fil.rmd.bam"

	soft = os.path.join(bindir, "Alignmentout_Sum.pl")
	tmpout += "perl %s " % soft + " -in %s " % fil_rmd_bam + \
			" -ref %s " % args.ref + \
			" -type bam" + \
			" -outpre %s " % args.prefix  + \
			" -outdir %s " % args.outdir + "\n" 

	print(tmpout, file=fh_tmp)
	fh_tmp.close()

def splicing():
	tmpfile = args.prefix + ".splicing.sh"
	fh_tmp = open(tmpfile, 'w')
	
	top=""
	bow=""
	if args.tophat:
		top=":%s" %args.tophat
	if args.bowtie:
		bow=":%s" %args.bowtie
	if (args.outdir==''):
		args.outdir = "%s" % workdir
	tmpout = "export PATH=$PATH:" + softdir + top + bow + "\n"
	# bowtie index
	tmpout += "bowtie2-build %s %s " % (args.vi, args.vi) + "\n"
	
	bowtie_index = re.sub(r'\.fa.*?$', "", args.vi)

	tmpout += "tophat  -r 10 -i 50  -I 4000 " +\
			" --library-type fr-unstranded -p 8 -o %s " % args.outdir +\
			bowtie_index
#PE reads
	if args.q2:
		tmpout += "  %s %s" % (args.q1, args.q2) +  "\n"
	else:
		tmpout += " %s" % (args.q1) +  "\n"

	hitbam = "%s " % args.outdir + "/accepted_hits.bam"
	soft = os.path.join(bindir, "Alignmentout_Sum.pl")
#	tmpout += "perl %s " % soft + " -in %s" % hitbam + " -type bam " +\
#			" -ref %s " % args.vi + \
#			" -outpre %s " % args.prefix + \
#			" -outdir %s " % workdir + "\n"
#	filter_bam = args.prefix + ".bam"

	soft = os.path.join(bindir, "Splicing_Search.pl")
	tmpout += "perl %s " % soft + " -in %s " % hitbam + \
			" -ref %s " % args.vi + "-outdir %s " % args.outdir + \
			" -outpre %s " % args.prefix + " -bam " + " 1 >> std.out  2>> std.err"

	print(tmpout, file=fh_tmp)
	fh_tmp.close()

############################################

if args.command == "search":
	search()
elif args.command == "assemble":
	assemble()
elif args.command == "splicing":
	splicing()
else:
	parser.print_help()
	exit(0)
